'use strict';
// ------- Osmo [https://osmo.supply/] ------- //

document.addEventListener("DOMContentLoaded", () => {
	// Register GSAP Plugins
  gsap.registerPlugin(ScrollTrigger);
  // Parallax Layers
  document.querySelectorAll('[data-parallax-layers]').forEach((triggerElement) => {
    let tl = gsap.timeline({
      scrollTrigger: {
        trigger: triggerElement,
        start: "0% 0%",
        end: "100% 0%",
        scrub: 0
      }
    });
    const layers = [
      { layer: "1", yPercent: 70 },
      { layer: "2", yPercent: 55 },
      { layer: "3", yPercent: 40 },
      { layer: "4", yPercent: 10 }
    ];
    layers.forEach((layerObj, idx) => {
      tl.to(
        triggerElement.querySelectorAll(`[data-parallax-layer="${layerObj.layer}"]`),
        {
          yPercent: layerObj.yPercent,
          ease: "none"
        },
        idx === 0 ? undefined : "<"
      );
    });
  });
});
/* Lenis */
const lenis = new Lenis();
lenis.on('scroll', ScrollTrigger.update);
gsap.ticker.add((time) => {lenis.raf(time * 1000);});
gsap.ticker.lagSmoothing(0);

document.addEventListener('DOMContentLoaded', function() {
  // Animation du header lors du défilement
  const header = document.querySelector('header');
  const scrollThreshold = 50;

  if (header) {
    window.addEventListener('scroll', function() {
        if (window.scrollY > scrollThreshold) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
  }

  // Animation des sections au défilement
  const sections = document.querySelectorAll('section');
  
  // Observer pour les animations au défilement
  const sectionObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
          if (entry.isIntersecting) {
              entry.target.classList.add('section-visible');
              
              // Animer les éléments à l'intérieur de la section
              const elements = entry.target.querySelectorAll('.animate-on-scroll');
              elements.forEach((el, index) => {
                  setTimeout(() => {
                      el.classList.add('visible');
                  }, 150 * index); // Délai progressif pour chaque élément
              });
          }
      });
  }, {
      threshold: 0.15,
      rootMargin: '-50px'
  });
  
  sections.forEach(section => {
      section.classList.add('section-hidden');
      sectionObserver.observe(section);
  });

  // Animation des cartes de troubles psychologiques
  const troubleCards = document.querySelectorAll('.trouble-card');
  
  troubleCards.forEach((card, index) => {
      card.classList.add('animate-on-scroll');
      card.style.transitionDelay = `${0.1 * index}s`;
      
      // Ajouter un effet de survol
      card.addEventListener('mouseenter', function() {
          this.classList.add('hovered');
      });
      
      card.addEventListener('mouseleave', function() {
          this.classList.remove('hovered');
      });
  });

  // Ajouter la classe animate-on-scroll aux éléments à animer
  document.querySelectorAll('.text-block, .video-placeholder, .image-container').forEach((element, index) => {
      element.classList.add('animate-on-scroll');
      element.style.transitionDelay = `${0.1 * index}s`;
  });

  // Animation des titres et sous-titres
  document.querySelectorAll('h3, p').forEach((element, index) => {
      element.classList.add('animate-on-scroll');
      element.style.transitionDelay = `${0.05 * index}s`;
  });

  // Défilement fluide pour les liens d'ancrage
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
          e.preventDefault();
          
          const targetId = this.getAttribute('href');
          const targetElement = document.querySelector(targetId);
          
          if (targetElement) {
              // Calculer la position de défilement en tenant compte de la hauteur du header fixe
              const headerHeight = header.offsetHeight;
              const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
              
              window.scrollTo({
                  top: targetPosition,
                  behavior: 'smooth'
              });
          }
      });
  });

  // Ajouter des effets visuels pour illustrer les troubles psychologiques
  // Ces effets sont subtils et peuvent être modifiés selon vos préférences
  
  // Effet de "dépression" - assombrit légèrement la page lors du survol de la carte
  const depressionCardOld = document.querySelector('.trouble-card:nth-child(1)');
  if (depressionCardOld) {
      depressionCardOld.addEventListener('mouseenter', function() {
          document.body.classList.add('depression-effect');
      });
      
      depressionCardOld.addEventListener('mouseleave', function() {
          document.body.classList.remove('depression-effect');
      });
  }
  
  // Animation pour l'image du personnage
  const imagePlaceholder = document.querySelector('.image-container');
  if (imagePlaceholder) {
      imagePlaceholder.addEventListener('mouseenter', function() {
          this.classList.add('image-hover');
      });
      
      imagePlaceholder.addEventListener('mouseleave', function() {
          this.classList.remove('image-hover');
      });
  }

  // Animation spéciale pour le logo
  const logo = document.querySelector('.logo img');
  if (logo) {
      logo.addEventListener('mouseenter', function() {
          this.style.animation = 'rotateIn 0.5s ease-out';
      });
      
      logo.addEventListener('mouseleave', function() {
          this.style.animation = 'pulse 2s infinite';
      });
  }

  // Ajouter un effet de parallaxe léger
  window.addEventListener('scroll', function() {
      const scrollPosition = window.pageYOffset;
      
      // Effet parallaxe pour les sections
      document.querySelectorAll('section').forEach(section => {
          const speed = 0.05;
          const yPos = -(scrollPosition * speed);
          section.style.backgroundPosition = `center ${yPos}px`;
      });
  });

  // Fonction pour gérer le son du battement de cœur sur la carte PTSD
  const ptsdCard = document.getElementById('ptsd-card');
  const heartbeatSound = document.getElementById('heartbeat-sound');
  
  if (ptsdCard && heartbeatSound) {
      // Régler le volume à un niveau approprié
      heartbeatSound.volume = 0.5;
      
      // Jouer le son quand la souris passe sur la carte
      ptsdCard.addEventListener('mouseenter', function() {
          heartbeatSound.currentTime = 0; // Remettre à zéro pour un démarrage immédiat
          
          // Utiliser une promesse pour gérer les erreurs de lecture
          const playPromise = heartbeatSound.play();
          
          if (playPromise !== undefined) {
              playPromise.catch(error => {
                  // Auto-play a été bloqué
                  console.log("La lecture automatique a été bloquée par le navigateur. L'utilisateur doit interagir avec la page d'abord.");
                  // Ne pas afficher d'erreur dans la console
              });
          }
      });
      
      // Arrêter le son quand la souris quitte la carte
      ptsdCard.addEventListener('mouseleave', function() {
          // Vérifier si le son est en cours de lecture
          if (!heartbeatSound.paused) {
              heartbeatSound.pause();
              heartbeatSound.currentTime = 0;
          }
      });
      
      // Ajouter un gestionnaire d'événements pour le premier clic sur la page
      document.addEventListener('click', function initAudio() {
          // Tenter de jouer et immédiatement mettre en pause pour débloquer l'audio
          heartbeatSound.play().then(() => {
              heartbeatSound.pause();
              heartbeatSound.currentTime = 0;
          }).catch(e => {
              // Ignorer les erreurs
          });
          
          // Supprimer cet écouteur d'événements après la première utilisation
          document.removeEventListener('click', initAudio);
      }, { once: true });
  }

  // Fonction pour gérer le son de respiration lourde sur la carte Anxiété
  const anxietyCard = document.getElementById('anxiety-card');
  const breathingSound = document.getElementById('breathing-sound');
  
  if (anxietyCard && breathingSound) {
      // Régler le volume à un niveau approprié
      breathingSound.volume = 0.4;
      
      // Jouer le son quand la souris passe sur la carte
      anxietyCard.addEventListener('mouseenter', function() {
          breathingSound.currentTime = 0; // Remettre à zéro pour un démarrage immédiat
          
          // Utiliser une promesse pour gérer les erreurs de lecture
          const playPromise = breathingSound.play();
          
          if (playPromise !== undefined) {
              playPromise.catch(error => {
                  // Auto-play a été bloqué
                  console.log("La lecture automatique a été bloquée par le navigateur. L'utilisateur doit interagir avec la page d'abord.");
                  // Ne pas afficher d'erreur dans la console
              });
          }
      });
      
      // Arrêter le son quand la souris quitte la carte
      anxietyCard.addEventListener('mouseleave', function() {
          // Vérifier si le son est en cours de lecture
          if (!breathingSound.paused) {
              breathingSound.pause();
              breathingSound.currentTime = 0;
          }
      });
      
      // Ajouter un gestionnaire d'événements pour le premier clic sur la page
      document.addEventListener('click', function initBreathingAudio() {
          // Tenter de jouer et immédiatement mettre en pause pour débloquer l'audio
          breathingSound.play().then(() => {
              breathingSound.pause();
              breathingSound.currentTime = 0;
          }).catch(e => {
              // Ignorer les erreurs
          });
          
          // Supprimer cet écouteur d'événements après la première utilisation
          document.removeEventListener('click', initBreathingAudio);
      }, { once: true });
  }

  // Effet de parallaxe pour l'effet sous-marin
  const underwaterSection = document.querySelector('.underwater-effect');
  if (underwaterSection) {
      window.addEventListener('scroll', function() {
          const scrollPosition = window.scrollY;
          const sectionTop = underwaterSection.offsetTop;
          const sectionHeight = underwaterSection.offsetHeight;
          
          // Vérifier si la section est visible à l'écran
          if (scrollPosition > sectionTop - window.innerHeight && 
              scrollPosition < sectionTop + sectionHeight) {
              
              // Calculer la position relative dans la section (0 à 1)
              const relativePosition = (scrollPosition - (sectionTop - window.innerHeight)) / 
                                      (sectionHeight + window.innerHeight);
              
              // Appliquer un effet de parallaxe aux bulles
              const bubbles = underwaterSection.querySelector('::before');
              if (bubbles) {
                  const translateY = 100 - (relativePosition * 200); // De 100% à -100%
                  bubbles.style.transform = `translateY(${translateY}%)`;
              }
              
              // Ajuster l'intensité de l'effet bleuté
              const overlay = underwaterSection.querySelector('::after');
              if (overlay) {
                  const opacity = 0.05 + (relativePosition * 0.1); // De 0.05 à 0.15
                  overlay.style.opacity = opacity;
              }
          }
      });
  }

  // Effet de flou et noir et blanc sur toute la page SAUF les blocs de dépression
  const depressionCard = document.getElementById('depression-card');
  const depressionText = document.getElementById('depression-text');
  const body = document.body;
  
  if (depressionCard && depressionText && body) {
      // Fonction pour activer l'effet
      function activateDepressionEffect() {
          body.classList.add('depression-effect-active');
      }
      
      // Fonction pour désactiver l'effet
      function deactivateDepressionEffect() {
          body.classList.remove('depression-effect-active');
      }
      
      // Activer l'effet UNIQUEMENT au survol de la carte de dépression
      depressionCard.addEventListener('mouseenter', activateDepressionEffect);
      depressionCard.addEventListener('mouseleave', deactivateDepressionEffect);
      
      // Supprimer les écouteurs d'événements sur le texte de dépression
      // depressionText.addEventListener('mouseenter', activateDepressionEffect);
      // depressionText.addEventListener('mouseleave', deactivateDepressionEffect);
  }
});